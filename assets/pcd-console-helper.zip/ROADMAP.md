# PCD Console Helper — Feature Roadmap

## Released

| Version | Branch / change | What shipped |
|---|---|---|
| v1.3 | `feature/1password-integration` | Native messaging host (`pf9_1p_helper.py`), 1Password SDK credential lookup, overlay form in active tab |
| v1.4 | `feature/secure-input` | Configurable vault name and item prefix in Options page |
| v1.5 | `feature/snippets` | Saved snippets (popup + full Options management, `chrome.storage.sync`); secure input mode; shift-key character encoding fix |
| v1.6.0 | `feature/keyboard-controls` | Open-popup keyboard shortcut (⌘+Shift+P / Ctrl+Shift+P); special key sender panel (Ctrl combos, navigation, arrows, F1–F12) |
| v1.6.1 | `fix/prefix-not-saving` | Bugfix: item prefix change in Options not reflected in test-connection status |
| v1.7.0 | `feature/clipboard-history` | Send history ring buffer (last 15 texts); re-send, delete individual items, clear all |
| v1.7.1 | `fix/dom-remove-error` | Bugfix: replace `innerHTML=''` with `replaceChildren()` to prevent `NotFoundError` on list clear |
| v1.7.2 | `fix/history-no-credentials` | Bugfix: credentials and secure-mode text no longer logged to send history |
| v1.7.3 | `fix/dom-focus-blur-race` | Bugfix: `safeClear()` helper blurs focused child before `replaceChildren()` to avoid blur-race |
| v1.7.4 | `fix/dom-rerender-deferred` | Bugfix: defer list re-renders with `setTimeout(fn, 0)` — final fix for `NotFoundError` on snippet/history delete |

---

## Planned feature branches

### `feature/keyboard-layout` _(later consideration)_
- **Keyboard layout selector** — non-US QWERTY users (UK, DE, FR, etc.) need a remapped `CHAR_MAP` in `content.js`; UI selector in options
- **Prerequisite**: test whether noVNC routes on `key` (the character) or `code` (physical position) against a non-US VM before implementing — if noVNC honours `key`, no layout map may be needed at all
- See testing notes: event inspector page + German/French layout VM test matrix

### `feature/snippet-enhancements`
- **Snippet folders / categories** — group snippets (e.g. "kubectl", "debug scripts") as the list grows; changes the storage data model
- **Variable substitution** — e.g. `{{instance}}` auto-filled from the URL, `{{date}}` from today, or prompted at send time
- **Import / export snippets** — JSON export/import for sharing snippet libraries across machines or with teammates; export schema should include folders

### `feature/clipboard-history` ✔ shipped in v1.7.0
- **Clipboard ring buffer** — keep a short history of recently sent texts so you can re-send without retyping; self-contained storage + popup UI change

### `feature/multiline-paste`
- **Line-by-line send with pause** — configurable delay between lines, useful for scripts or commands that need time to execute before the next line is sent
- **Paste speed profiles** — named presets (Slow / Normal / Fast) instead of a raw ms-per-character number

### `feature/novnc-detection` _(implemented, not yet merged)_
- **Auto-detect noVNC pages** — implemented on `feature/novnc-detection` branch; shows an orange `VNC` badge on noVNC tabs, teal `✓` badge takes priority when credentials are loaded; touches `background.js` only

### `feature/cross-platform-install`
- **Linux installer** — update `install.sh` with Linux Chrome/Chromium native messaging host paths (`~/.config/google-chrome/NativeMessagingHosts/`)
- **Windows installer** — new `install.ps1`; writes the native messaging manifest path into the Windows registry instead of a file path; uses `Scripts\python.exe` venv layout

### `feature/credential-improvements`
- **Credential cache TTL** — configurable time before cached credentials expire (currently cleared on browser close only)
- **Token health check** — periodically verify the 1Password service account token is still valid; surface a warning in the options page before it expires
- **Multiple vault support** — select from a list of configured vaults rather than one fixed vault name
- **Manual credential fallback** — typed-in username/password fields stored in session only, never persisted; useful when 1Password is unavailable

---

## Grouping rationale

| Group together | Why |
|---|---|
| Keyboard shortcut + special key sender | Both touch `manifest.json` and `content.js` |
| Snippet folders + variable substitution + import/export | Share the same storage data model change |
| Linux installer + Windows installer | Purely in `native/`; testable independently of extension JS |

| Do separately | Why |
|---|---|
| Clipboard history | Self-contained; no overlap with other planned work |
| Multi-line paste | Isolated to `content.js` send logic + small popup UI tweak |
| noVNC detection | Touches service worker (`background.js`); worth separate review |
| Keyboard layout selector | Needs noVNC behaviour testing first to determine approach; separate branch when ready |
| Per-instance snippet pinning | Depends on snippet folder work being merged first |
| Credential improvements | Keeps credential code reviewable on its own |
