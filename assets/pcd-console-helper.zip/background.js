/**
 * background.js — Platform9 noVNC Console Paste
 *
 * Service worker running persistently in the background.
 *
 * Solves the popup-lifecycle problem: when the user clicks on the active tab
 * to let 1Password fill the injected overlay form, Chrome closes the popup
 * and destroys any chrome.runtime.onMessage listeners registered there.
 *
 * This service worker acts as a persistent relay:
 *   1. content.js sends PF9_1P_FILLED → here (always alive).
 *   2. We write credentials to chrome.storage.session (cleared on browser close).
 *   3. We badge the extension icon so the user knows creds are ready.
 *   4. When the user reopens the popup, popup.js reads storage on init and
 *      auto-loads the pending credentials.
 */

'use strict';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'PF9_1P_FILLED') {
    const tabId = sender.tab?.id ?? null;

    // Persist credentials in session storage (survives popup open/close cycles,
    // cleared automatically when the browser session ends).
    chrome.storage.session
      .set({
        pf9_pending_creds: {
          username: msg.username || '',
          password: msg.password || '',
          instance: msg.instance  || '',
          tabId,
          ts: Date.now(),
        },
      })
      .then(() => {
        // Badge the icon so the user sees that credentials are waiting.
        if (tabId != null) {
          chrome.action.setBadgeText({ text: '✓', tabId });
          chrome.action.setBadgeBackgroundColor({ color: '#1a9e94', tabId });
        }
      });

    sendResponse({ ok: true });
  }
  return false;
});
