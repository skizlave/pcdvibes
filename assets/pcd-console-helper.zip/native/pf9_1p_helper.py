#!/usr/bin/env python3
"""
pf9_1p_helper.py — Platform9 noVNC 1Password credential helper

Native messaging host for the Platform9 noVNC Paste Chrome extension.
Called on-demand by the extension; reads one request from stdin, writes
one response to stdout, then exits.

Message format: 4-byte little-endian length prefix + UTF-8 JSON body
(Chrome native messaging protocol).

Uses the 1Password Python SDK (onepassword-sdk) — NO `op` CLI binary is
ever spawned, so no macOS TCC privacy prompts occur.  The SDK authenticates
directly with 1Password using the service account token.

Config file: ~/.pf9-helper/config.json
  {
    "token":  "ops_...",    // 1Password service account token
    "vault":  "platform9",  // vault name shown in 1Password
    "prefix": "PF9 - "     // prepended to instance name → item title
  }
"""

import sys
import json
import struct
import os
import asyncio

CONFIG_PATH = os.path.expanduser('~/.pf9-helper/config.json')


# ── Native messaging I/O ──────────────────────────────────────────────────────

def read_message():
    raw_len = sys.stdin.buffer.read(4)
    if len(raw_len) < 4:
        sys.exit(0)
    msg_len = struct.unpack('=I', raw_len)[0]
    return json.loads(sys.stdin.buffer.read(msg_len).decode('utf-8'))


def send_message(obj):
    data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('=I', len(data)))
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


# ── 1Password SDK lookup ──────────────────────────────────────────────────────

async def sdk_resolve(token, vault, item_title):
    """
    Resolve username + password via the 1Password SDK secret reference:
        op://<vault>/<item>/username
        op://<vault>/<item>/password
    """
    from onepassword.client import Client  # noqa: import inside function for clean error msg

    client = await Client.authenticate(
        auth=token,
        integration_name='pf9-novnc-paste',
        integration_version='1.3.0',
    )

    ref = f'op://{vault}/{item_title}'
    username = await client.secrets.resolve(f'{ref}/username')
    password = await client.secrets.resolve(f'{ref}/password')
    return username, password


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    try:
        msg = read_message()
    except Exception as e:
        send_message({'error': f'Failed to read message: {e}'})
        return

    msg_type = msg.get('type')

    try:
        with open(CONFIG_PATH) as f:
            config = json.load(f)
    except FileNotFoundError:
        send_message({'ok': False, 'error': 'Config not found — run native/install.sh'})
        return
    except Exception as e:
        send_message({'ok': False, 'error': f'Could not read config: {e}'})
        return

    token  = config.get('token', '').strip()
    prefix = config.get('prefix', 'PF9 - ')
    vault  = config.get('vault', '').strip()

    # ── Ping / health-check ───────────────────────────────────────────────────
    if msg_type == 'PF9_1P_PING':
        send_message({
            'ok':       True,
            'hasToken': bool(token),
            'vault':    vault,
            'prefix':   prefix,
        })
        return

    # ── Credential lookup ─────────────────────────────────────────────────────
    if msg_type == 'PF9_1P_GET_CREDS':
        instance = msg.get('instance', '').strip()
        if not instance:
            send_message({'error': 'No instance name provided'})
            return
        if not token:
            send_message({'error': 'Service account token not set — run install.sh'})
            return

        # Allow the extension's Options page vault/prefix to override config.json
        vault  = msg.get('vault')  or vault
        prefix = msg.get('prefix') or config.get('prefix', 'PF9 - ')

        if not vault:
            send_message({'error': 'Vault name not set — configure it in the extension Settings or re-run install.sh'})
            return
        item_title = f'{prefix}{instance}'

        try:
            username, password = asyncio.run(sdk_resolve(token, vault, item_title))
            send_message({'username': username, 'password': password, 'item': item_title})
        except ImportError:
            send_message({
                'error': 'onepassword-sdk not installed — re-run native/install.sh'
            })
        except Exception as e:
            err = str(e)
            if 'no item matched' in err.lower() or 'secret reference' in err.lower():
                send_message({'error': f'No matching VM instance found for "{instance}" — expected item "{item_title}" in vault "{vault}"'})
            else:
                send_message({'error': err})
        return

    send_message({'error': f'Unknown message type: {msg_type}'})


if __name__ == '__main__':
    main()
