#!/usr/bin/env bash
# =============================================================================
# Platform9 noVNC Paste Extension — 1Password Helper Installer
# =============================================================================
#
# What this does:
#   1. Copies the native messaging host script to ~/.pf9-helper/
#   2. Writes your service account token + item prefix to ~/.pf9-helper/config.json
#      (chmod 600 — readable only by you)
#   3. Registers the Chrome native messaging manifest so the extension can call
#      the helper directly (no browser restart needed after installation).
#
# Requirements:
#   - macOS
#   - Python 3 (pre-installed on macOS 12+)
#   - 1Password Business/Teams plan with a service account token
#     (1Password.com → Settings → Developer → Service Accounts → New)
#
# No 1Password CLI needed — credentials are fetched via the REST API.
#
# Usage:
#   cd pf9-paste-extension/native
#   bash install.sh
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HELPER_DIR="$HOME/.pf9-helper"
HELPER_SCRIPT="$HELPER_DIR/pf9_1p_helper.py"
CONFIG_FILE="$HELPER_DIR/config.json"
MANIFEST_NAME="com.platform9.novnc.helper"
CHROME_HOST_DIR="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
CHROMIUM_HOST_DIR="$HOME/Library/Application Support/Chromium/NativeMessagingHosts"

# ── Banner ────────────────────────────────────────────────────────────────────
echo ""
echo "  ┌─────────────────────────────────────────────────────────┐"
echo "  │  Platform9 noVNC Extension — 1Password Helper Installer │"
echo "  └─────────────────────────────────────────────────────────┘"
echo ""

# ── Check for Python 3 & install 1Password SDK ───────────────────────────────
if ! command -v python3 &>/dev/null; then
  echo "  ✗  python3 not found."
  echo "  Install Python 3 from https://www.python.org or via Homebrew: brew install python3"
  exit 1
fi
PYTHON_PATH="$(command -v python3)"
echo "  ✓  Found $(python3 --version) at $PYTHON_PATH"

echo ""
echo "  Creating isolated Python environment and installing 1Password SDK…"
VENV_DIR="$HELPER_DIR/venv"
"$PYTHON_PATH" -m venv "$VENV_DIR"
VENV_PYTHON="$VENV_DIR/bin/python3"
"$VENV_PYTHON" -m pip install --quiet --upgrade onepassword-sdk

# Verify install
if ! "$VENV_PYTHON" -c 'import onepassword' 2>/dev/null; then
  echo "  ✗  Failed to install onepassword-sdk."
  echo "  Try manually: $VENV_PYTHON -m pip install onepassword-sdk"
  exit 1
fi
echo "  ✓  onepassword-sdk installed in $VENV_DIR"

# ── Extension ID ──────────────────────────────────────────────────────────────
echo ""
echo "  To connect the helper to your extension, we need its Extension ID."
echo ""
echo "  1. Open Chrome and go to:  chrome://extensions"
echo "  2. Enable 'Developer mode' (top-right toggle)"
echo "  3. Find 'Platform9 noVNC Paste' and copy the ID shown below its name."
echo ""
echo "  Alternatively, open the extension's Options page — the ID is shown there."
echo ""
read -rp "  Paste Extension ID here: " EXTENSION_ID
EXTENSION_ID="${EXTENSION_ID// /}"  # strip spaces

if [[ ! "$EXTENSION_ID" =~ ^[a-z]{32}$ ]]; then
  echo ""
  echo "  ✗  That doesn't look like a valid Chrome Extension ID (32 lowercase letters)."
  echo "  Please re-run this script and try again."
  exit 1
fi

# ── Service account token ─────────────────────────────────────────────────────
echo ""
echo "  Enter your 1Password service account token."
echo "  Create one at: 1password.com → Settings → Developer → Service Accounts"
echo "  The token starts with 'ops_'."
echo ""
read -rsp "  Service account token (hidden): " OP_TOKEN
echo ""

if [[ -z "$OP_TOKEN" ]]; then
  echo ""
  echo "  ✗  No token entered. You can re-run this script or set it later in"
  echo "     the extension's Options page."
  OP_TOKEN=""
fi

# ── Item prefix ───────────────────────────────────────────────────────────────echo ""
echo "  Vault name in 1Password that contains your VM credentials."
  echo "  This is the exact vault name shown in 1Password (case-insensitive)."
echo ""
read -rp "  Vault name [Private]: " VAULT_NAME
VAULT_NAME="${VAULT_NAME:-Private}"

# ── Item prefix ─────────────────────────────────────────────────────────────────echo ""
echo "  Item title prefix in 1Password."
echo "  The extension looks up an item named: <prefix><instance-name>"
echo "  Example: prefix=\"PF9 - \", instance=\"demo\" → looks up \"PF9 - demo\""
echo ""
read -rp "  Item prefix [PF9 - ]: " ITEM_PREFIX
ITEM_PREFIX="${ITEM_PREFIX:-PF9 - }"

# ── Create helper directory ───────────────────────────────────────────────────
mkdir -p "$HELPER_DIR"
chmod 700 "$HELPER_DIR"

# Copy script and stamp the venv python path into the shebang so Chrome
# always uses the exact interpreter that has onepassword-sdk installed.
cp "$SCRIPT_DIR/pf9_1p_helper.py" "$HELPER_SCRIPT"
"$PYTHON_PATH" -c "
path='$HELPER_SCRIPT'; venv='$VENV_PYTHON'
lines=open(path).read().split('\n'); lines[0]='#!'+venv
open(path,'w').write('\n'.join(lines))
"
chmod 755 "$HELPER_SCRIPT"
echo "  ✓  Helper installed (shebang: #!${VENV_PYTHON})"

# ── Write config ──────────────────────────────────────────────────────────────
cat > "$CONFIG_FILE" <<EOF
{
  "token":  "$OP_TOKEN",
  "vault":  "$VAULT_NAME",
  "prefix": "$ITEM_PREFIX"
}
EOF
chmod 600 "$CONFIG_FILE"
echo ""
echo "  ✓  Config written to: $CONFIG_FILE"

# ── Write Chrome native messaging manifest ────────────────────────────────────
write_manifest() {
  local dir="$1"
  mkdir -p "$dir"
  cat > "$dir/$MANIFEST_NAME.json" <<EOF
{
  "name": "$MANIFEST_NAME",
  "description": "Platform9 noVNC 1Password credential helper",
  "path": "$HELPER_SCRIPT",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://$EXTENSION_ID/"
  ]
}
EOF
  echo "  ✓  Manifest written to: $dir/$MANIFEST_NAME.json"
}

write_manifest "$CHROME_HOST_DIR"

# Also write for Chromium if it exists
if [[ -d "$(dirname "$CHROMIUM_HOST_DIR")" ]]; then
  write_manifest "$CHROMIUM_HOST_DIR"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo "  ┌─────────────────────────────────────────────────────────┐"
echo "  │  Installation complete!                                  │"
echo "  └─────────────────────────────────────────────────────────┘"
echo ""
echo "  Next steps:"
echo "  1. Reload the extension in Chrome (chrome://extensions → ↺ button)"
echo "  2. Open any PCD noVNC console URL (the one with ?instance=...)"
echo "  3. The extension will auto-load credentials for that VM from 1Password"
echo ""
echo "  To update the token or prefix later, edit: $CONFIG_FILE"
echo "  Or re-run this script."
echo ""
