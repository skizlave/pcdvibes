/**
 * content.js — Platform9 noVNC Console Paste
 *
 * Runs in the context of the active tab.  Listens for PF9_PASTE messages
 * from the popup, finds the noVNC canvas, and replays keystrokes.
 *
 * noVNC keyboard handling:
 *   - The library listens for native DOM keyboard events on its canvas.
 *   - We dispatch keydown + keypress (for legacy compat) + keyup sequences.
 *   - For special characters (newline → Enter, tab, etc.) we use the
 *     correct key/code/keyCode values.
 */

'use strict';

// Guard: only register once per page
if (!window.__pf9PasteInjected) {
  window.__pf9PasteInjected = true;

  // ── Special key map ────────────────────────────────────────────────────────
  // Maps control / whitespace characters → { key, code, keyCode }
  const SPECIAL_KEYS = {
    '\n': { key: 'Enter',     code: 'Enter',     keyCode: 13 },
    '\r': { key: 'Enter',     code: 'Enter',     keyCode: 13 },
    '\t': { key: 'Tab',       code: 'Tab',       keyCode: 9  },
    '\b': { key: 'Backspace', code: 'Backspace', keyCode: 8  },
  };

  // ── Printable character map ────────────────────────────────────────────────
  // Maps each printable character to the PHYSICAL key it lives on (US QWERTY)
  // together with whether Shift must be held.  This lets us send synthetised
  // KeyboardEvents with the correct code/keyCode/shiftKey so noVNC can derive
  // the right X keysym regardless of which event property it reads.
  const CHAR_MAP = {
    // unshifted digits
    '0': { code: 'Digit0',       keyCode: 48 },
    '1': { code: 'Digit1',       keyCode: 49 },
    '2': { code: 'Digit2',       keyCode: 50 },
    '3': { code: 'Digit3',       keyCode: 51 },
    '4': { code: 'Digit4',       keyCode: 52 },
    '5': { code: 'Digit5',       keyCode: 53 },
    '6': { code: 'Digit6',       keyCode: 54 },
    '7': { code: 'Digit7',       keyCode: 55 },
    '8': { code: 'Digit8',       keyCode: 56 },
    '9': { code: 'Digit9',       keyCode: 57 },
    // shifted digits
    '!': { code: 'Digit1',       keyCode: 49, shiftKey: true },
    '@': { code: 'Digit2',       keyCode: 50, shiftKey: true },
    '#': { code: 'Digit3',       keyCode: 51, shiftKey: true },
    '$': { code: 'Digit4',       keyCode: 52, shiftKey: true },
    '%': { code: 'Digit5',       keyCode: 53, shiftKey: true },
    '^': { code: 'Digit6',       keyCode: 54, shiftKey: true },
    '&': { code: 'Digit7',       keyCode: 55, shiftKey: true },
    '*': { code: 'Digit8',       keyCode: 56, shiftKey: true },
    '(': { code: 'Digit9',       keyCode: 57, shiftKey: true },
    ')': { code: 'Digit0',       keyCode: 48, shiftKey: true },
    // unshifted punctuation
    ' ': { code: 'Space',        keyCode: 32 },
    '-': { code: 'Minus',        keyCode: 189 },
    '=': { code: 'Equal',        keyCode: 187 },
    '[': { code: 'BracketLeft',  keyCode: 219 },
    ']': { code: 'BracketRight', keyCode: 221 },
    '\\':{ code: 'Backslash',    keyCode: 220 },
    ';': { code: 'Semicolon',    keyCode: 186 },
    "'": { code: 'Quote',        keyCode: 222 },
    '`': { code: 'Backquote',    keyCode: 192 },
    ',': { code: 'Comma',        keyCode: 188 },
    '.': { code: 'Period',       keyCode: 190 },
    '/': { code: 'Slash',        keyCode: 191 },
    // shifted punctuation
    '_': { code: 'Minus',        keyCode: 189, shiftKey: true },
    '+': { code: 'Equal',        keyCode: 187, shiftKey: true },
    '{': { code: 'BracketLeft',  keyCode: 219, shiftKey: true },
    '}': { code: 'BracketRight', keyCode: 221, shiftKey: true },
    '|': { code: 'Backslash',    keyCode: 220, shiftKey: true },
    ':': { code: 'Semicolon',    keyCode: 186, shiftKey: true },
    '"': { code: 'Quote',        keyCode: 222, shiftKey: true },
    '~': { code: 'Backquote',    keyCode: 192, shiftKey: true },
    '<': { code: 'Comma',        keyCode: 188, shiftKey: true },
    '>': { code: 'Period',       keyCode: 190, shiftKey: true },
    '?': { code: 'Slash',        keyCode: 191, shiftKey: true },
  };

  // Return { code, keyCode, shiftKey } for any printable character.
  function getCharProps(char) {
    if (CHAR_MAP[char]) return CHAR_MAP[char];
    const lower = char.toLowerCase();
    if (lower >= 'a' && lower <= 'z') {
      // a-z: KeyA-KeyZ, keyCode 65-90; uppercase needs Shift
      return { code: `Key${lower.toUpperCase()}`, keyCode: lower.toUpperCase().charCodeAt(0), shiftKey: char !== lower };
    }
    // Fallback for any other character
    return { code: `Key${char.toUpperCase()}`, keyCode: char.charCodeAt(0), shiftKey: false };
  }

  // ── Find the best noVNC target element ────────────────────────────────────
  function findNoVNCTarget() {
    // Preferred: the noVNC canvas by ID (most common)
    const byId = document.getElementById('noVNC_canvas');
    if (byId) return byId;

    // Fallback 1: canvas inside noVNC container divs
    const containerSelectors = [
      '.noVNC_container canvas',
      '#noVNC_container canvas',
      '#app canvas',
      'canvas',
    ];
    for (const sel of containerSelectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }

    // Fallback 2: any canvas in the page
    const allCanvas = document.querySelectorAll('canvas');
    if (allCanvas.length === 1) return allCanvas[0];

    // Fallback 3: the focused element or body
    return document.activeElement || document.body;
  }

  // ── Build a keyboard event ─────────────────────────────────────────────────
  function makeKeyEvent(type, char, extra = {}) {
    const special = SPECIAL_KEYS[char];
    if (special) {
      return new KeyboardEvent(type, {
        bubbles: true, cancelable: true, composed: true,
        key: special.key, code: special.code,
        keyCode: special.keyCode, which: special.keyCode,
        charCode: type === 'keypress' ? special.keyCode : 0,
        shiftKey: false, ctrlKey: false, altKey: false, metaKey: false,
        ...extra,
      });
    }

    const { code, keyCode: physKeyCode, shiftKey = false } = getCharProps(char);
    const charCode = char.charCodeAt(0);
    // keypress: keyCode = char code (matches real browser behaviour)
    // keydown / keyup: keyCode = physical key code
    const keyCode = type === 'keypress' ? charCode : physKeyCode;
    return new KeyboardEvent(type, {
      bubbles:    true,
      cancelable: true,
      composed:   true,          // cross shadow-DOM
      key:        char,
      code,
      keyCode,
      which:      keyCode,
      charCode:   type === 'keypress' ? charCode : 0,
      shiftKey,
      ctrlKey:    false,
      altKey:     false,
      metaKey:    false,
      ...extra,
    });
  }

  // ── Synthesise a Shift modifier event ────────────────────────────────────
  function makeShiftEvent(type) {
    return new KeyboardEvent(type, {
      bubbles: true, cancelable: true, composed: true,
      key: 'Shift', code: 'ShiftLeft', keyCode: 16, which: 16,
      charCode: 0,
      // shiftKey is true while the key is held (i.e. on keydown, false on keyup)
      shiftKey: type === 'keydown',
      ctrlKey: false, altKey: false, metaKey: false,
    });
  }

  // ── Send a single character ────────────────────────────────────────────────
  function sendChar(target, char) {
    // For characters that require Shift, bracket them with explicit Shift
    // keydown/keyup events so noVNC's internal modifier-state machine sees
    // Shift as held — relying solely on shiftKey:true in the char event is
    // not sufficient for all noVNC versions.
    const needsShift = !SPECIAL_KEYS[char] && !!getCharProps(char).shiftKey;

    if (needsShift) target.dispatchEvent(makeShiftEvent('keydown'));
    target.dispatchEvent(makeKeyEvent('keydown',  char));
    target.dispatchEvent(makeKeyEvent('keypress', char));
    target.dispatchEvent(makeKeyEvent('keyup',    char));
    if (needsShift) target.dispatchEvent(makeShiftEvent('keyup'));
  }

  // ── Delay helper ──────────────────────────────────────────────────────────
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // ── Focus the target before typing ────────────────────────────────────────
  function ensureFocus(target) {
    try {
      if (target !== document.activeElement) {
        target.focus({ preventScroll: true });
      }
    } catch (_) { /* ignore */ }
  }

  // ── Special key definitions ──────────────────────────────────────────────
  // Each entry: { key, code, keyCode, ctrlKey?, altKey? }
  const SPECIAL_KEY_DEFS = {
    // Modifier combos
    'ctrl+c':     { key: 'c',      code: 'KeyC',        keyCode: 67,  ctrlKey: true  },
    'ctrl+z':     { key: 'z',      code: 'KeyZ',        keyCode: 90,  ctrlKey: true  },
    'ctrl+d':     { key: 'd',      code: 'KeyD',        keyCode: 68,  ctrlKey: true  },
    'ctrl+l':     { key: 'l',      code: 'KeyL',        keyCode: 76,  ctrlKey: true  },
    'ctrl+a':     { key: 'a',      code: 'KeyA',        keyCode: 65,  ctrlKey: true  },
    'ctrl+r':     { key: 'r',      code: 'KeyR',        keyCode: 82,  ctrlKey: true  },
    // Navigation / control
    'escape':     { key: 'Escape', code: 'Escape',      keyCode: 27  },
    'tab':        { key: 'Tab',    code: 'Tab',         keyCode: 9   },
    'enter':      { key: 'Enter',  code: 'Enter',       keyCode: 13  },
    'backspace':  { key: 'Backspace', code: 'Backspace',keyCode: 8   },
    'delete':     { key: 'Delete', code: 'Delete',      keyCode: 46  },
    'home':       { key: 'Home',   code: 'Home',        keyCode: 36  },
    'end':        { key: 'End',    code: 'End',         keyCode: 35  },
    'pageup':     { key: 'PageUp', code: 'PageUp',      keyCode: 33  },
    'pagedown':   { key: 'PageDown', code: 'PageDown',  keyCode: 34  },
    // Arrow keys
    'arrowup':    { key: 'ArrowUp',    code: 'ArrowUp',    keyCode: 38 },
    'arrowdown':  { key: 'ArrowDown',  code: 'ArrowDown',  keyCode: 40 },
    'arrowleft':  { key: 'ArrowLeft',  code: 'ArrowLeft',  keyCode: 37 },
    'arrowright': { key: 'ArrowRight', code: 'ArrowRight', keyCode: 39 },
    // Function keys
    'f1':  { key: 'F1',  code: 'F1',  keyCode: 112 },
    'f2':  { key: 'F2',  code: 'F2',  keyCode: 113 },
    'f3':  { key: 'F3',  code: 'F3',  keyCode: 114 },
    'f4':  { key: 'F4',  code: 'F4',  keyCode: 115 },
    'f5':  { key: 'F5',  code: 'F5',  keyCode: 116 },
    'f6':  { key: 'F6',  code: 'F6',  keyCode: 117 },
    'f7':  { key: 'F7',  code: 'F7',  keyCode: 118 },
    'f8':  { key: 'F8',  code: 'F8',  keyCode: 119 },
    'f9':  { key: 'F9',  code: 'F9',  keyCode: 120 },
    'f10': { key: 'F10', code: 'F10', keyCode: 121 },
    'f11': { key: 'F11', code: 'F11', keyCode: 122 },
    'f12': { key: 'F12', code: 'F12', keyCode: 123 },
  };

  // Send a named special key (ctrl+c, escape, f1, arrowup, etc.)
  function sendSpecialKey(target, name) {
    const def = SPECIAL_KEY_DEFS[name.toLowerCase()];
    if (!def) return;

    const { key, code, keyCode, ctrlKey = false, altKey = false } = def;

    const make = (type) => new KeyboardEvent(type, {
      bubbles: true, cancelable: true, composed: true,
      key, code, keyCode, which: keyCode, charCode: 0,
      shiftKey: false, ctrlKey, altKey, metaKey: false,
    });

    target.dispatchEvent(make('keydown'));
    target.dispatchEvent(make('keyup'));
  }

  // ── Main message listener ─────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'PF9_SPECIAL_KEY') {
      const target = findNoVNCTarget();
      ensureFocus(target);
      sendSpecialKey(target, msg.key);
      sendResponse({ ok: true });
      return false;
    }
    if (msg.type === 'PF9_PASTE') {
      (async () => {
        const { text, delay } = msg;
        const target = findNoVNCTarget();

        ensureFocus(target);

        let sent = 0;
        for (const char of text) {
          sendChar(target, char);
          sent++;

          // Report progress back to popup (best-effort)
          try {
            chrome.runtime.sendMessage({ type: 'PF9_PROGRESS', sent });
          } catch (_) { /* popup may be closed */ }

          if (delay > 0) await sleep(delay);
        }

        sendResponse({ success: true, charsSent: sent });
      })();
      return true; // keep channel open for async sendResponse
    }

    // ── 1Password detection via DOM markers ───────────────────────────────
    if (msg.type === 'PF9_1P_DETECT') {
      // 1Password injects recognisable attributes and elements into every page
      const markers = [
        () => !!document.querySelector('[data-1p-ignore]'),
        () => !!document.querySelector('[data-op-id]'),
        () => !!document.querySelector('com-1password-button'),
        () => !!document.getElementById('__1PAssistantBadge__'),
        () => document.documentElement.hasAttribute('data-1p-shortcut-barrier'),
        () => !!document.querySelector('[class*="onepassword"]'),
        () => typeof window.__SAFARI_KEYCHAIN_EXTENSION__ !== 'undefined',
      ];
      const detected = markers.some(fn => { try { return fn(); } catch { return false; } });
      sendResponse({ detected });
      return false;
    }

    // ── 1Password shadow-field injection ──────────────────────────────────
    if (msg.type === 'PF9_1P_INJECT') {
      injectShadowForm(msg.instanceName || '');
      sendResponse({ ok: true });
      return false;
    }

    if (msg.type === 'PF9_1P_CANCEL') {
      removeShadowForm();
      sendResponse({ ok: true });
      return false;
    }

    return false;
  });

  // ── Shadow form ────────────────────────────────────────────────────────────
  // We inject a real (but visually hidden) login form into the page so that
  // 1Password's content script detects it and offers to fill credentials.
  // When the fields are filled we capture the values and relay them to the popup.

  let _shadowContainer = null;

  function injectShadowForm(instanceName) {
    removeShadowForm(); // clean up any previous instance

    const container = document.createElement('div');
    container.id = '__pf9_1p_shadow__';

    // Visible overlay — 1Password ignores off-screen / opacity:0 fields
    Object.assign(container.style, {
      position:        'fixed',
      top:             '0',
      left:            '0',
      width:           '100%',
      height:          '100%',
      background:      'rgba(0,0,0,0.55)',
      zIndex:          '2147483647',
      display:         'flex',
      alignItems:      'center',
      justifyContent:  'center',
      fontFamily:      '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    });

    container.innerHTML = `
      <div style="
        background:#fff;
        border-radius:10px;
        padding:24px 28px;
        width:320px;
        box-shadow:0 8px 40px rgba(0,0,0,0.25);
        display:flex;
        flex-direction:column;
        gap:14px;
      ">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <span style="font-size:15px;font-weight:700;color:#1a2332;">
            ${instanceName ? `Fill credentials for: <span style="color:#FF5A00">${instanceName}</span>` : 'Fill with 1Password'}
          </span>
          <button id="__pf9_1p_dismiss__" style="
            background:none;border:none;cursor:pointer;
            font-size:18px;color:#7a96b0;line-height:1;padding:0 2px;
          ">✕</button>
        </div>
        <p style="font-size:12px;color:#5a6e82;margin:0;">
          Click the 1Password icon in the field below to select a credential.
        </p>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label for="__pf9_user__" style="font-size:11px;font-weight:600;color:#5a6e82;text-transform:uppercase;letter-spacing:.05em;">Username</label>
          <input id="__pf9_user__"
                 type="text"
                 name="username"
                 autocomplete="username"
                 placeholder="Click the 1Password icon →"
                 style="
                   width:100%;box-sizing:border-box;
                   padding:8px 10px;font-size:13px;
                   border:1.5px solid #dde3ea;border-radius:6px;
                   outline:none;color:#1a2332;
                 " />
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label for="__pf9_pass__" style="font-size:11px;font-weight:600;color:#5a6e82;text-transform:uppercase;letter-spacing:.05em;">Password</label>
          <input id="__pf9_pass__"
                 type="password"
                 name="password"
                 autocomplete="current-password"
                 placeholder="••••••••"
                 style="
                   width:100%;box-sizing:border-box;
                   padding:8px 10px;font-size:13px;
                   border:1.5px solid #dde3ea;border-radius:6px;
                   outline:none;color:#1a2332;
                 " />
        </div>
        <p style="font-size:11px;color:#5a6e82;margin:0;text-align:center;">
          Credentials are sent to the console and never stored.
        </p>
      </div>
    `;

    document.body.appendChild(container);
    _shadowContainer = container;

    const userField = container.querySelector('#__pf9_user__');
    const passField = container.querySelector('#__pf9_pass__');

    // Focus the password field so 1Password's icon appears immediately
    setTimeout(() => passField.focus(), 100);

    // Dismiss button closes without sending
    container.querySelector('#__pf9_1p_dismiss__').addEventListener('click', () => {
      removeShadowForm();
      try { chrome.runtime.sendMessage({ type: 'PF9_1P_CANCELLED' }); } catch (_) {}
    });

    // Click outside the card also dismisses
    container.addEventListener('click', (e) => {
      if (e.target === container) {
        removeShadowForm();
        try { chrome.runtime.sendMessage({ type: 'PF9_1P_CANCELLED' }); } catch (_) {}
      }
    });

    // Capture fill — listen for both input and change events
    function tryCapture() {
      const user = userField.value;
      const pass = passField.value;
      if (pass) {
        try {
          chrome.runtime.sendMessage({
            type:     'PF9_1P_FILLED',
            username: user,
            password: pass,
            instance: instanceName,
          });
        } catch (_) {}
        removeShadowForm();
      }
    }

    ['input', 'change', 'blur'].forEach(evt => {
      userField.addEventListener(evt, tryCapture);
      passField.addEventListener(evt, tryCapture);
    });

    // Polling fallback every 300 ms
    let polls = 0;
    const pollId = setInterval(() => {
      polls++;
      if (passField && passField.value) {
        clearInterval(pollId);
        tryCapture();
      }
      if (polls > 100) clearInterval(pollId); // 30 s
    }, 300);

    container._pollId = pollId;
  }

  function removeShadowForm() {
    if (_shadowContainer) {
      if (_shadowContainer._pollId) clearInterval(_shadowContainer._pollId);
      _shadowContainer.remove();
      _shadowContainer = null;
    }
  }
}
