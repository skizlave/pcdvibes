/**
 * options.js — Platform9 noVNC Paste extension settings page
 */

'use strict';

// Safely clear a container's children. Explicitly blurs any focused child
// first so Chrome's focus management finishes before the DOM is torn down,
// preventing NotFoundError during replaceChildren() on Chrome MV3.
function safeClear(container) {
  const focused = container.querySelector(':focus');
  if (focused) focused.blur();
  container.replaceChildren();
}

const helperStatus     = document.getElementById('helperStatus');
const helperDot        = document.getElementById('helperDot');
const helperStatusText = document.getElementById('helperStatusText');
const installSteps     = document.getElementById('installSteps');
const testBtn          = document.getElementById('testBtn');
const extensionIdEl    = document.getElementById('extensionId');
const copyIdBtn        = document.getElementById('copyIdBtn');
const copyNotice       = document.getElementById('copyNotice');
const vaultName        = document.getElementById('vaultName');
const itemPrefix       = document.getElementById('itemPrefix');
const saveBtn          = document.getElementById('saveBtn');
const saveNotice       = document.getElementById('saveNotice');
const opEnabledToggle  = document.getElementById('opEnabledToggle');
const dependentCards   = document.getElementById('dependentCards');

const NATIVE_HOST = 'com.platform9.novnc.helper';

// ── Extension ID ──────────────────────────────────────────────────────────────
extensionIdEl.textContent = chrome.runtime.id;

copyIdBtn.addEventListener('click', () => {
  navigator.clipboard.writeText(chrome.runtime.id).then(() => {
    copyNotice.style.display = 'inline';
    setTimeout(() => { copyNotice.style.display = 'none'; }, 2000);
  });
});

// ── Load saved preferences ────────────────────────────────────────────────────
chrome.storage.local.get('pf9_settings', (data) => {
  const s = data.pf9_settings || {};
  vaultName.value  = s.vault  ?? '';
  itemPrefix.value = s.prefix ?? 'PF9 - ';
  const enabled = s.opEnabled !== false; // default ON
  opEnabledToggle.checked = enabled;
  applyToggleState(enabled);

  if (enabled) testConnection();
});

function applyToggleState(enabled) {
  dependentCards.classList.toggle('disabled', !enabled);
}

opEnabledToggle.addEventListener('change', () => {
  const enabled = opEnabledToggle.checked;
  applyToggleState(enabled);
  saveSettings(() => {
    if (enabled) testConnection();
  });});

// ── Save preferences ──────────────────────────────────────────────────────────
function saveSettings(cb) {
  chrome.storage.local.set({
    pf9_settings: {
      vault:     vaultName.value.trim(),
      prefix:    itemPrefix.value || 'PF9 - ',
      opEnabled: opEnabledToggle.checked,
    },
  }, cb);
}

saveBtn.addEventListener('click', () => {
  saveSettings(() => {
    saveNotice.style.display = 'inline';
    setTimeout(() => { saveNotice.style.display = 'none'; }, 2000);
  });
});

// ── Test native messaging connection ─────────────────────────────────────────
function setHelperStatus(state, text) {
  helperStatus.className = `status-row ${state}`;
  helperDot.className    = `dot ${state}`;
  helperStatusText.textContent = text;
  installSteps.style.display = (state === 'error') ? '' : 'none';
}

function testConnection() {
  testBtn.disabled = true;
  setHelperStatus('idle', 'Connecting to native helper…');

  try {
    chrome.runtime.sendNativeMessage(NATIVE_HOST, { type: 'PF9_1P_PING' }, (resp) => {
      testBtn.disabled = false;

      if (chrome.runtime.lastError) {
        const err = chrome.runtime.lastError.message || 'Native host not found';
        setHelperStatus('error', `Helper not found — ${err}`);
        return;
      }

      if (resp && resp.ok) {
        const vault  = resp.vault  || '';
        const prefix = resp.prefix || 'PF9 - ';
        // Only auto-populate fields that are still empty (initial setup).
        // Never overwrite a value the user has already saved.
        if (vault  && !vaultName.value)  vaultName.value  = vault;
        if (!itemPrefix.value)           itemPrefix.value = prefix;
        if (resp.hasToken) {
          // Show the effective prefix (what the extension will actually use).
          setHelperStatus('ok', `Connected ✓  (prefix: "${itemPrefix.value}")`);
        } else {
          setHelperStatus('error', 'Helper found but no token set — re-run install.sh');
        }
      } else {
        const msg = resp?.error || 'Unknown error';
        setHelperStatus('error', msg);
      }
    });
  } catch (e) {
    testBtn.disabled = false;
    setHelperStatus('error', `Could not send message: ${e.message}`);
  }
}

testBtn.addEventListener('click', testConnection);

// ── Snippets management ───────────────────────────────────────────────────────
const SNIPPETS_KEY     = 'pf9_snippets';
const optSnippetsList  = document.getElementById('optSnippetsList');
const optSnippetsEmpty = document.getElementById('optSnippetsEmpty');

function loadAndRenderSnippets() {
  chrome.storage.sync.get(SNIPPETS_KEY, (data) => {
    renderSnippetsMgmt(data[SNIPPETS_KEY] || []);
  });
}

function renderSnippetsMgmt(snippets) {
  safeClear(optSnippetsList);
  optSnippetsEmpty.style.display = snippets.length ? 'none' : '';
  snippets.forEach((s) => {
    const row = document.createElement('div');
    row.className = 'snippet-mgmt-row';

    // ─ header: label input + delete button
    const header = document.createElement('div');
    header.className = 'snippet-mgmt-header';

    const labelInput = document.createElement('input');
    labelInput.type = 'text';
    labelInput.value = s.label;
    labelInput.maxLength = 60;
    labelInput.placeholder = 'Snippet name';
    labelInput.title = 'Click to rename';
    labelInput.addEventListener('change', () => {
      const newLabel = labelInput.value.trim();
      if (!newLabel) { labelInput.value = s.label; return; }
      updateSnippetField(s.id, 'label', newLabel);
    });

    const delBtn = document.createElement('button');
    delBtn.className = 'btn-del-snippet';
    delBtn.textContent = 'Delete';
    delBtn.addEventListener('click', () => {
      chrome.storage.sync.get(SNIPPETS_KEY, (d) => {
        const snips = (d[SNIPPETS_KEY] || []).filter(sn => sn.id !== s.id);
        chrome.storage.sync.set({ [SNIPPETS_KEY]: snips }, () => setTimeout(loadAndRenderSnippets, 0));
      });
    });

    header.appendChild(labelInput);
    header.appendChild(delBtn);

    // ─ body: editable text
    const textArea = document.createElement('textarea');
    textArea.className = 'snippet-text-edit';
    textArea.value = s.text;
    textArea.spellcheck = false;
    textArea.addEventListener('change', () => {
      updateSnippetField(s.id, 'text', textArea.value);
    });

    row.appendChild(header);
    row.appendChild(textArea);
    optSnippetsList.appendChild(row);
  });
}

function updateSnippetField(id, field, value) {
  chrome.storage.sync.get(SNIPPETS_KEY, (d) => {
    const snips = d[SNIPPETS_KEY] || [];
    const idx = snips.findIndex(sn => sn.id === id);
    if (idx >= 0) {
      snips[idx][field] = value;
      chrome.storage.sync.set({ [SNIPPETS_KEY]: snips });
    }
  });
}

loadAndRenderSnippets();
