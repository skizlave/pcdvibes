/**
 * onepassword.js — Platform9 noVNC Paste
 *
 * Option B: Detect and interact with the 1Password browser extension by
 * injecting shadow (hidden) input fields into the active page.  1Password's
 * content script auto-detects password fields and offers to fill them.  We
 * capture whatever it fills via a MutationObserver in content.js and forward
 * the values back here.
 *
 * Known 1Password Chrome extension IDs:
 *   aeblfdkhhhdcdjpifhhbdiojplfjncoa  — 1Password (current)
 *   aomjjhallfgjeglblehebfpbcfeobpgk  — 1Password X (legacy)
 */

'use strict';

const OP_EXTENSION_IDS = [
  'aeblfdkhhhdcdjpifhhbdiojplfjncoa', // 1Password – Password Manager
  'aomjjhallfgjeglblehebfpbcfeobpgk', // 1Password X (legacy)
];

/**
 * Probe each known 1Password extension ID.
 * Returns the first ID that responds, or null if none is installed/enabled.
 */
async function detect1Password() {
  for (const id of OP_EXTENSION_IDS) {
    try {
      const resp = await new Promise((resolve) => {
        chrome.runtime.sendMessage(id, { action: 'pf9_ping' }, (r) => {
          if (chrome.runtime.lastError) resolve(null);
          else resolve(r ?? true);   // any response = present
        });
      });
      if (resp !== null) return id;
    } catch (_) { /* not installed */ }
  }
  return null;
}

/**
 * Ask the content script to inject shadow input fields into the active page.
 * 1Password will detect the password field and show its fill UI.
 *
 * @param {number} tabId  - active tab
 * @returns {Promise<{username:string, password:string}|null>}
 */
async function requestCredentialFill(tabId) {
  // Ensure latest content script is loaded
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js'],
    });
  } catch (_) { /* already loaded */ }

  return new Promise((resolve) => {
    // Timeout after 30 s in case user dismisses 1Password without filling
    const timer = setTimeout(() => {
      chrome.tabs.sendMessage(tabId, { type: 'PF9_1P_CANCEL' });
      resolve(null);
    }, 30000);

    // One-shot listener for the filled credentials coming back
    const handler = (msg) => {
      if (msg.type !== 'PF9_1P_FILLED') return;
      clearTimeout(timer);
      chrome.runtime.onMessage.removeListener(handler);
      resolve({ username: msg.username, password: msg.password });
    };
    chrome.runtime.onMessage.addListener(handler);

    // Tell the content script to inject the shadow form
    chrome.tabs.sendMessage(tabId, { type: 'PF9_1P_INJECT' }, (r) => {
      if (chrome.runtime.lastError || (r && r.error)) {
        clearTimeout(timer);
        chrome.runtime.onMessage.removeListener(handler);
        resolve(null);
      }
    });
  });
}

export { detect1Password, requestCredentialFill };
