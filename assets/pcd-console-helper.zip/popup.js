/**
 * popup.js — Platform9 noVNC Console Paste
 *
 * Coordinates between the popup UI and the content script that injects
 * keystrokes into the active noVNC canvas.
 */

// Safely clear a container's children. Explicitly blurs any focused child
// first so Chrome's focus management finishes before the DOM is torn down,
// preventing NotFoundError during replaceChildren() on Chrome MV3.
function safeClear(container) {
  const focused = container.querySelector(':focus');
  if (focused) focused.blur();
  container.replaceChildren();
}

const pasteText  = document.getElementById('pasteText');
const sendBtn    = document.getElementById('sendBtn');
const clearBtn   = document.getElementById('clearBtn');
const sendEnter  = document.getElementById('sendEnter');
const clearAfter = document.getElementById('clearAfter');
const charDelay  = document.getElementById('charDelay');
const statusDot  = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const progressBar = document.getElementById('progressBar');

// ── Secure mode elements ────────────────────────────────────────────────────
const secureModeToggle = document.getElementById('secureModeToggle');
const secureInputBlock = document.getElementById('secureInputBlock');
const secureText       = document.getElementById('secureText');
const revealBtn        = document.getElementById('revealBtn');
const eyeIcon          = document.getElementById('eyeIcon');

// ── Secure mode state ───────────────────────────────────────────────────────
let _isSecureMode = false;

// ── Persistence ────────────────────────────────────────────────────────────
(function restorePrefs() {
  const saved = JSON.parse(localStorage.getItem('pf9_prefs') || '{}');
  if (saved.sendEnter  !== undefined) sendEnter.checked  = saved.sendEnter;
  if (saved.clearAfter !== undefined) clearAfter.checked = saved.clearAfter;
  if (saved.charDelay  !== undefined) charDelay.value    = saved.charDelay;
})();

function savePrefs() {
  localStorage.setItem('pf9_prefs', JSON.stringify({
    sendEnter:  sendEnter.checked,
    clearAfter: clearAfter.checked,
    charDelay:  charDelay.value,
  }));
}

[sendEnter, clearAfter, charDelay].forEach(el =>
  el.addEventListener('change', savePrefs)
);

// ── Secure mode toggle ──────────────────────────────────────────────────────
secureModeToggle.addEventListener('click', () => {
  _isSecureMode = !_isSecureMode;
  secureModeToggle.classList.toggle('active', _isSecureMode);

  if (_isSecureMode) {
    // Switch to secure input
    pasteText.style.display = 'none';
    secureInputBlock.style.display = 'flex';
    secureText.type = 'password';  // ensure masked on entry
    secureText.value = '';
    secureText.focus();
  } else {
    // Switch back to plain textarea
    secureInputBlock.style.display = 'none';
    secureText.value = '';          // wipe the secret immediately
    pasteText.style.display = '';
    pasteText.focus();
  }
  setStatus('idle', 'Ready');
});

// ── Eye (reveal) toggle ──────────────────────────────────────────────────────
// Eye-open SVG path constants
const EYE_OPEN_PATHS = [
  '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>',
  '<circle cx="12" cy="12" r="3"/>',
].join('');
const EYE_CLOSED_PATHS = [
  '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>',
  '<path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>',
  '<line x1="1" y1="1" x2="23" y2="23"/>',
].join('');

revealBtn.addEventListener('click', () => {
  const isHidden = secureText.type === 'password';
  secureText.type = isHidden ? 'text' : 'password';
  // Swap icon: show crossed-eye when revealing (to indicate click will re-hide)
  eyeIcon.innerHTML = isHidden ? EYE_OPEN_PATHS : EYE_CLOSED_PATHS;
  revealBtn.title = isHidden ? 'Hide input' : 'Show input';
});

// Ctrl/Cmd+Enter from the secure input triggers send
secureText.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    e.preventDefault();
    sendBtn.click();
  }
});

// ── Status helpers ──────────────────────────────────────────────────────────
function setStatus(state, message) {
  statusDot.className  = `status-dot ${state}`;
  statusText.className = `status-text ${state === 'sending' ? '' : state}`;
  statusText.textContent = message;
  if (state !== 'sending') progressBar.style.width = '0%';
}

function setProgress(pct) {
  progressBar.style.width = `${pct}%`;
}

// ── Clear button ────────────────────────────────────────────────────────────
clearBtn.addEventListener('click', () => {
  if (_isSecureMode) {
    secureText.value = '';
    secureText.type = 'password';       // re-mask if was revealed
    eyeIcon.innerHTML = EYE_CLOSED_PATHS;
    revealBtn.title = 'Show input';
    secureText.focus();
  } else {
    pasteText.value = '';
    pasteText.focus();
  }
  setStatus('idle', 'Ready');
});

// ── Send button ─────────────────────────────────────────────────────────────
sendBtn.addEventListener('click', async () => {
  let text = _isSecureMode ? secureText.value : pasteText.value;
  if (!text && !sendEnter.checked) {
    setStatus('error', 'Nothing to send');
    return;
  }

  if (sendEnter.checked) text += '\n';

  const delay = Math.max(0, parseInt(charDelay.value, 10) || 0);

  sendBtn.disabled = true;
  setStatus('sending', `Sending 0 / ${text.length} chars…`);
  setProgress(0);

  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) {
    setStatus('error', 'No active tab found');
    sendBtn.disabled = false;
    return;
  }

  // Inject the content script on demand (handles pages that loaded before the
  // extension was installed, or non-matching host_permissions edge cases).
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js'],
    });
  } catch (_) {
    // Already injected or a restricted page — silently proceed.
  }

  // Send message; track per-character progress via responses
  chrome.tabs.sendMessage(
    tab.id,
    {
      type: 'PF9_PASTE',
      text,
      delay,
    },
    (response) => {
      if (chrome.runtime.lastError) {
        setStatus('error', 'Could not reach page. Is a noVNC console open?');
        sendBtn.disabled = false;
        return;
      }

      if (response && response.success) {
        setStatus('success', `Sent ${response.charsSent} character${response.charsSent === 1 ? '' : 's'} ✓`);
        setProgress(100);
        if (_isSecureMode) {
          // Always wipe secure input after send (regardless of clearAfter setting)
          secureText.value = '';
          secureText.type = 'password';   // re-mask in case it was revealed
          eyeIcon.innerHTML = EYE_CLOSED_PATHS;
          revealBtn.title = 'Show input';
        } else {
          // Record in history — skip for credential/secure sends
          if (!_suppressHistory) addToHistory(text);
          _suppressHistory = false;
          if (clearAfter.checked) pasteText.value = '';
        }
      } else {
        const msg = response && response.error ? response.error : 'Unknown error';
        setStatus('error', msg);
      }
      sendBtn.disabled = false;
    }
  );

  // Optimistic progress animation while waiting (actual progress comes from
  // content script via chrome.runtime.sendMessage updates).
  watchProgress(text.length);
});

// ── Optimistic progress ticker ──────────────────────────────────────────────
function watchProgress(totalChars) {
  // Listen for progress updates from content script
  const handler = (msg) => {
    if (msg.type !== 'PF9_PROGRESS') return;
    const pct = Math.round((msg.sent / totalChars) * 100);
    setProgress(pct);
    statusText.textContent = `Sending ${msg.sent} / ${totalChars} chars…`;

    if (msg.sent >= totalChars) {
      chrome.runtime.onMessage.removeListener(handler);
    }
  };
  chrome.runtime.onMessage.addListener(handler);
}

// Allow Ctrl+Enter / Cmd+Enter from the textarea as a shortcut
pasteText.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    e.preventDefault();
    sendBtn.click();
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// Credentials section — 1Password (Option B)
// ═══════════════════════════════════════════════════════════════════════════

const credsToggle    = document.getElementById('credsToggle');
const credsBody      = document.getElementById('credsBody');
const credsChevron   = document.querySelector('.creds-chevron');
const opDot          = document.getElementById('opDot');
const opStatus       = document.getElementById('opStatus');
const loadFromOpBtn  = document.getElementById('loadFromOpBtn');
const credUsername   = document.getElementById('credUsername');
const credPassword   = document.getElementById('credPassword');
const sendUsernameBtn = document.getElementById('sendUsernameBtn');
const sendPasswordBtn = document.getElementById('sendPasswordBtn');
const instanceRow    = document.getElementById('instanceRow');
const instanceNameEl = document.getElementById('instanceName');
const setupGuide     = document.getElementById('setupGuide');
const credsMain      = document.getElementById('credsMain');
const credsHeaderStatus = document.getElementById('credsHeaderStatus');

// Helper: update both the in-panel status and the collapsed-header hint
function setOpStatus(text, headerText, state) {
  opStatus.textContent = text;
  if (credsHeaderStatus) {
    credsHeaderStatus.textContent = headerText || '';
    credsHeaderStatus.className = 'creds-header-status' + (state ? ` ${state}` : '');
  }
}


// State
let _opDetected = false;
let _helperWorking = false;   // true once PF9_1P_PING confirms helper is installed
let _vault  = '';             // overridden by pf9_settings.vault from options
let _prefix = 'PF9 - ';       // overridden by pf9_settings.prefix from options
let _credentials = { username: '', password: '' };
let _instanceName = '';
let _currentTabId = null;
let _suppressHistory = false;  // set by credential/secure sends to skip history logging

// ── Toggle open/close ────────────────────────────────────────────────────────
credsToggle.addEventListener('click', () => {
  const open = credsBody.classList.toggle('open');
  credsChevron.classList.toggle('open', open);
  credsToggle.setAttribute('aria-expanded', open);
  // init runs on popup open; no need to re-detect here
});
// ── Instance context init (runs on popup open) ───────────────────────────
async function initInstanceContext() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  _currentTabId = tab.id;

  // Extract instance name from console URL (?instance=<vm-name>)
  try {
    const url = new URL(tab.url);
    const inst = url.searchParams.get('instance');
    if (inst) {
      _instanceName = inst;
      instanceNameEl.textContent = inst;
      instanceRow.style.display = '';
    }
  } catch (_) { /* non-parseable URL, ignore */ }

  // ① Check session cache first — avoids an API call on every popup open
  const session = await chrome.storage.session.get('pf9_pending_creds');
  const pending  = session.pf9_pending_creds;
  if (pending && pending.tabId === tab.id) {
    _credentials = { username: pending.username, password: pending.password };
    updateCredentialDisplay();
    opDot.className = 'op-dot detected';
    const inst = pending.instance || _instanceName;
    setOpStatus(
      inst ? `Credentials loaded for "${inst}" ✓` : 'Credentials loaded ✓',
      'Loaded ✓',
      'ok',
    );
    loadFromOpBtn.disabled = false;
    _helperWorking = true;
    _opDetected = true;
    chrome.storage.session.remove('pf9_pending_creds');
    chrome.action.setBadgeText({ text: '', tabId: tab.id });
    return;
  }

  // ② Ping helper to determine whether it is installed.
  //    Show setup guide ONLY if it is not.
  const helperOk = await pingHelper();
  if (!helperOk) {
    showSetupGuide();
    setOpStatus('1Password helper not set up', '', '');
    loadFromOpBtn.disabled = false;
    _opDetected = true;
    return;
  }

  // Helper confirmed working — always keep guide hidden
  _helperWorking = true;

  // ③ Auto-lookup when instance name is known
  if (_instanceName) {
    await autoLookupViaHelper(_instanceName);
  } else {
    opDot.className = 'op-dot detected';
    setOpStatus('1Password connected', '', 'ok');
    loadFromOpBtn.disabled = false;
    _opDetected = true;
  }
}

const NATIVE_HOST = 'com.platform9.novnc.helper';

// ── Show/hide setup guide ─────────────────────────────────────────────────────
function hideSetupGuide() {
  if (setupGuide) setupGuide.style.display = 'none';
}

function showSetupGuide() {
  if (setupGuide) setupGuide.style.display = '';
}

// Ping helper — returns a promise resolving to true if installed and working
function pingHelper() {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendNativeMessage(NATIVE_HOST, { type: 'PF9_1P_PING' }, (resp) => {
        resolve(!chrome.runtime.lastError && resp && resp.ok);
      });
    } catch (_) {
      resolve(false);
    }
  });
}

// ── 1Password native helper auto-lookup ──────────────────────────────────────
// Returns true if credentials were successfully loaded, false otherwise.
function autoLookupViaHelper(instance) {
  return new Promise((resolve) => {
    opDot.className = 'op-dot waiting';
    opStatus.textContent = `Looking up "${instance}" in 1Password…`;

    try {
      chrome.runtime.sendNativeMessage(
        NATIVE_HOST,
        { type: 'PF9_1P_GET_CREDS', instance, vault: _vault || undefined, prefix: _prefix },
        (resp) => {
          if (chrome.runtime.lastError || !resp) {
            // Helper disappeared mid-session (shouldn't happen after ping)
            opDot.className = 'op-dot missing';
            setOpStatus('Helper unavailable', 'Unavailable', 'err');
            loadFromOpBtn.disabled = false;
            _opDetected = true;
            resolve(false);
            return;
          }

          if (resp.error) {
            // Helper working but item not found
            opDot.className = 'op-dot missing';
            setOpStatus(`1Password: ${resp.error}`, 'Not found', 'err');
            loadFromOpBtn.disabled = false;
            _opDetected = true;
            resolve(false);
            return;
          }

          // Success
          _credentials = { username: resp.username || '', password: resp.password || '' };
          updateCredentialDisplay();
          opDot.className = 'op-dot detected';
          setOpStatus(
            `Auto-loaded from 1Password ✓  (${resp.item || instance})`,
            'Auto-loaded ✓',
            'ok',
          );
          loadFromOpBtn.disabled = false;
          _opDetected = true;
          // Cache so subsequent opens skip the API call
          chrome.storage.session.set({
            pf9_pending_creds: {
              tabId:    _currentTabId,
              username: resp.username || '',
              password: resp.password || '',
              instance: resp.item || instance,
            },
          });
          resolve(true);
        }
      );
    } catch (e) {
      opDot.className = 'op-dot missing';
      setOpStatus('Helper error — try again', '', 'err');
      loadFromOpBtn.disabled = false;
      _opDetected = true;
      resolve(false);
    }
  });
}

function openCredsPanel() {
  if (!credsBody.classList.contains('open')) {
    credsBody.classList.add('open');
    credsChevron.classList.add('open');
    credsToggle.setAttribute('aria-expanded', 'true');
  }
}

// ── Detect 1Password extension ───────────────────────────────────────────────
async function detect1Password() {
  opDot.className = 'op-dot waiting';
  opStatus.textContent = 'Checking for 1Password…';

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) {
    opDot.className = 'op-dot missing';
    opStatus.textContent = '1Password not detected';
    return;
  }

  // Ensure content script is present
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
  } catch (_) { /* already loaded */ }

  // Ask content script to look for 1Password DOM markers
  chrome.tabs.sendMessage(tab.id, { type: 'PF9_1P_DETECT' }, (resp) => {
    if (chrome.runtime.lastError || !resp) {
      // Can't reach page (e.g. chrome:// URL) — just enable optimistically
      _opDetected = true;
      opDot.className = 'op-dot detected';
      opStatus.textContent = '1Password (assumed present)';
      loadFromOpBtn.disabled = false;
      return;
    }
    if (resp.detected) {
      _opDetected = true;
      opDot.className = 'op-dot detected';
      opStatus.textContent = '1Password detected';
      loadFromOpBtn.disabled = false;
    } else {
      // Still enable — user may have 1Password installed but not active on this page yet
      _opDetected = true;
      opDot.className = 'op-dot detected';
      opStatus.textContent = '1Password (click to trigger fill)';
      loadFromOpBtn.disabled = false;
    }
  });
}

// ── Load from 1Password ──────────────────────────────────────────────────────
loadFromOpBtn.addEventListener('click', async () => {
  loadFromOpBtn.disabled = true;
  opDot.className = 'op-dot waiting';
  setOpStatus('Looking up in 1Password…', '…', '');

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) {
    setOpStatus('No active tab found', '', 'err');
    opDot.className = 'op-dot missing';
    loadFromOpBtn.disabled = false;
    return;
  }

  // If the native helper is installed and we have an instance name,
  // try it first. Only fall back to the 1Password browser overlay if
  // the helper doesn't have a matching item.
  if (_helperWorking && _instanceName) {
    const success = await autoLookupViaHelper(_instanceName);
    if (success) {
      loadFromOpBtn.disabled = false;
      return;
    }
    // Helper didn't find it — fall through to browser overlay
    setOpStatus('Not found via helper — opening 1Password…', '…', '');
  }

  // ── 1Password browser-extension overlay fallback ──
  opStatus.textContent = 'Waiting for 1Password fill… (select credential in page)';

  // Ensure content script is loaded
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
  } catch (_) { /* already loaded */ }

  // Listen for the fill result from the content script
  const TIMEOUT_MS = 45000;
  const timer = setTimeout(() => {
    cleanup();
    opDot.className = 'op-dot missing';
    opStatus.textContent = 'Timed out — no credential selected';
    loadFromOpBtn.disabled = false;
    chrome.tabs.sendMessage(tab.id, { type: 'PF9_1P_CANCEL' });
  }, TIMEOUT_MS);

  function cleanup() {
    clearTimeout(timer);
    chrome.runtime.onMessage.removeListener(fillHandler);
  }

  function fillHandler(msg) {
    if (msg.type === 'PF9_1P_CANCELLED') {
      cleanup();
      opDot.className = 'op-dot detected';
      opStatus.textContent = 'Cancelled — no credential selected';
      loadFromOpBtn.disabled = false;
      return;
    }
    if (msg.type !== 'PF9_1P_FILLED') return;
    cleanup();
    _credentials = { username: msg.username || '', password: msg.password || '' };
    updateCredentialDisplay();
    opDot.className = 'op-dot detected';
    setOpStatus('Credentials loaded ✓', 'Loaded ✓', 'ok');
    loadFromOpBtn.disabled = false;
    hideSetupGuide();
    // Clear any session storage the background may have written simultaneously
    chrome.storage.session.remove('pf9_pending_creds');
    if (_currentTabId != null) chrome.action.setBadgeText({ text: '', tabId: _currentTabId });
  }

  chrome.runtime.onMessage.addListener(fillHandler);

  // Tell content script to inject shadow form (pass instance name as hint)
  chrome.tabs.sendMessage(tab.id, { type: 'PF9_1P_INJECT', instanceName: _instanceName }, (r) => {
    if (chrome.runtime.lastError || (r && r.error)) {
      cleanup();
      opDot.className = 'op-dot missing';
      opStatus.textContent = 'Could not inject into page';
      loadFromOpBtn.disabled = false;
    }
  });
});

// ── Update credential display ────────────────────────────────────────────────
function updateCredentialDisplay() {
  if (_credentials.username) {
    credUsername.textContent = _credentials.username;
    credUsername.classList.remove('empty');
    sendUsernameBtn.disabled = false;
  } else {
    credUsername.textContent = 'not loaded';
    credUsername.classList.add('empty');
    sendUsernameBtn.disabled = true;
  }
  if (_credentials.password) {
    credPassword.textContent = '•'.repeat(Math.min(_credentials.password.length, 20));
    credPassword.classList.remove('empty');
    sendPasswordBtn.disabled = false;
  } else {
    credPassword.textContent = 'not loaded';
    credPassword.classList.add('empty');
    sendPasswordBtn.disabled = true;
  }
}

// ── Send username / password to console ─────────────────────────────────────
sendUsernameBtn.addEventListener('click', () => {
  if (_credentials.username) {
    _suppressHistory = true;
    pasteText.value = _credentials.username + '\n';
    const prev = sendEnter.checked;
    sendEnter.checked = false;
    sendBtn.click();
    sendEnter.checked = prev;
  }
});

sendPasswordBtn.addEventListener('click', () => {
  if (_credentials.password) {
    _suppressHistory = true;
    pasteText.value = _credentials.password + '\n';
    const prev = sendEnter.checked;
    sendEnter.checked = false;
    sendBtn.click();
    sendEnter.checked = prev;
  }
});
// ═══════════════════════════════════════════════════════════════════════════
// Snippets section
// ═══════════════════════════════════════════════════════════════════════════

const snippetsToggle    = document.getElementById('snippetsToggle');
const snippetsBody      = document.getElementById('snippetsBody');
const snippetsChevron   = document.getElementById('snippetsChevron');
const snippetsList      = document.getElementById('snippetsList');
const snippetAddRow     = document.getElementById('snippetAddRow');
const snippetAddBtn     = document.getElementById('snippetAddBtn');
const snippetLabelInput = document.getElementById('snippetLabelInput');
const snippetSaveBtn    = document.getElementById('snippetSaveBtn');
const snippetCancelBtn  = document.getElementById('snippetCancelBtn');
const snippetsCount     = document.getElementById('snippetsCount');

const SNIPPETS_KEY = 'pf9_snippets';
let _snippets = [];

function loadSnippets() {
  chrome.storage.sync.get(SNIPPETS_KEY, (data) => {
    _snippets = data[SNIPPETS_KEY] || [];
    renderSnippets();
  });
}

function saveSnippets(cb) {
  chrome.storage.sync.set({ [SNIPPETS_KEY]: _snippets }, cb);
}

function renderSnippets() {
  snippetsCount.textContent = _snippets.length ? `${_snippets.length}` : '';
  safeClear(snippetsList);
  if (_snippets.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'snippet-empty';
    empty.textContent = 'No snippets saved yet';
    snippetsList.appendChild(empty);
    return;
  }
  _snippets.forEach((s) => {
    const row = document.createElement('div');
    row.className = 'snippet-row';

    const labelEl = document.createElement('span');
    labelEl.className = 'snippet-label';
    labelEl.textContent = s.label;
    labelEl.title = s.text;

    const snipSendBtn = document.createElement('button');
    snipSendBtn.className = 'btn-cred';
    snipSendBtn.textContent = 'Send';
    snipSendBtn.addEventListener('click', () => {
      if (_isSecureMode) secureModeToggle.click(); // exit secure mode
      pasteText.value = s.text;
      sendBtn.click();
    });

    const delBtn = document.createElement('button');
    delBtn.className = 'btn-snippet-del';
    delBtn.title = 'Delete snippet';
    delBtn.textContent = '\u00d7';
    delBtn.addEventListener('click', () => {
      _snippets = _snippets.filter(sn => sn.id !== s.id);
      saveSnippets(() => setTimeout(renderSnippets, 0));
    });

    row.appendChild(labelEl);
    row.appendChild(snipSendBtn);
    row.appendChild(delBtn);
    snippetsList.appendChild(row);
  });
}

snippetsToggle.addEventListener('click', () => {
  const open = snippetsBody.classList.toggle('open');
  snippetsChevron.classList.toggle('open', open);
  snippetsToggle.setAttribute('aria-expanded', open);
});

snippetAddBtn.addEventListener('click', () => {
  if (_isSecureMode) {
    setStatus('error', 'Exit secure mode first');
    setTimeout(() => setStatus('idle', 'Ready'), 2000);
    return;
  }
  if (!pasteText.value.trim()) {
    setStatus('error', 'Type text in the input field first');
    setTimeout(() => setStatus('idle', 'Ready'), 2000);
    return;
  }
  snippetAddRow.style.display = 'flex';
  snippetAddBtn.style.display = 'none';
  snippetLabelInput.value = '';
  snippetLabelInput.focus();
});

snippetCancelBtn.addEventListener('click', () => {
  snippetAddRow.style.display = 'none';
  snippetAddBtn.style.display = '';
});

function commitSaveSnippet() {
  const text = pasteText.value;
  if (!text) return;
  const label = snippetLabelInput.value.trim() || `Snippet ${_snippets.length + 1}`;
  _snippets.push({ id: Date.now(), label, text });
  saveSnippets(() => {
    renderSnippets();
    snippetAddRow.style.display = 'none';
    snippetAddBtn.style.display = '';
  });
}

snippetSaveBtn.addEventListener('click', commitSaveSnippet);
snippetLabelInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); commitSaveSnippet(); }
  if (e.key === 'Escape') { snippetCancelBtn.click(); }
});

loadSnippets();

// ═══════════════════════════════════════════════════════════════════════════
// Clipboard History section
// ═══════════════════════════════════════════════════════════════════════════

const historyToggle   = document.getElementById('historyToggle');
const historyBody     = document.getElementById('historyBody');
const historyChevron  = document.getElementById('historyChevron');
const historyList     = document.getElementById('historyList');
const historyCount    = document.getElementById('historyCount');
const historyClearBtn = document.getElementById('historyClearBtn');
const historyClearRow = document.getElementById('historyClearRow');

const HISTORY_KEY = 'pf9_history';
const HISTORY_MAX = 15;
let _history = [];

function loadHistory() {
  chrome.storage.local.get(HISTORY_KEY, (data) => {
    _history = data[HISTORY_KEY] || [];
    renderHistory();
  });
}

function saveHistory(cb) {
  chrome.storage.local.set({ [HISTORY_KEY]: _history }, cb);
}

function addToHistory(text) {
  if (!text || !text.trim()) return;
  // Deduplicate: move to top if the same text was already sent recently
  _history = _history.filter(h => h.text !== text);
  _history.unshift({ id: Date.now(), text, ts: Date.now() });
  if (_history.length > HISTORY_MAX) _history = _history.slice(0, HISTORY_MAX);
  saveHistory(() => renderHistory());
}

function renderHistory() {
  historyCount.textContent = _history.length ? `${_history.length}` : '';
  historyClearRow.style.display = _history.length ? '' : 'none';
  safeClear(historyList);

  if (_history.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'history-empty';
    empty.textContent = 'No history yet — sent texts will appear here';
    historyList.appendChild(empty);
    return;
  }

  _history.forEach((h) => {
    const row = document.createElement('div');
    row.className = 'snippet-row';

    const label = document.createElement('span');
    label.className = 'snippet-label';
    const preview = h.text.length > 60 ? h.text.slice(0, 57) + '\u2026' : h.text;
    label.textContent = preview;
    label.title = h.text;

    const reSendBtn = document.createElement('button');
    reSendBtn.className = 'btn-cred';
    reSendBtn.textContent = 'Send';
    reSendBtn.addEventListener('click', () => {
      if (_isSecureMode) secureModeToggle.click(); // exit secure mode first
      pasteText.value = h.text;
      sendBtn.click();
    });

    const delBtn = document.createElement('button');
    delBtn.className = 'btn-snippet-del';
    delBtn.title = 'Remove from history';
    delBtn.textContent = '\u00d7';
    delBtn.addEventListener('click', () => {
      _history = _history.filter(item => item.id !== h.id);
      saveHistory(() => setTimeout(renderHistory, 0));
    });

    row.appendChild(label);
    row.appendChild(reSendBtn);
    row.appendChild(delBtn);
    historyList.appendChild(row);
  });
}

historyToggle.addEventListener('click', () => {
  const open = historyBody.classList.toggle('open');
  historyChevron.classList.toggle('open', open);
  historyToggle.setAttribute('aria-expanded', open);
});

historyClearBtn.addEventListener('click', () => {
  _history = [];
  saveHistory(() => setTimeout(renderHistory, 0));
});

loadHistory();

// ═══════════════════════════════════════════════════════════════════════════
// Special Keys section
// ═══════════════════════════════════════════════════════════════════════════

const keysToggle  = document.getElementById('keysToggle');
const keysBody    = document.getElementById('keysBody');
const keysChevron = document.getElementById('keysChevron');

keysToggle.addEventListener('click', () => {
  const open = keysBody.classList.toggle('open');
  keysChevron.classList.toggle('open', open);
  keysToggle.setAttribute('aria-expanded', open);
});

async function sendSpecialKey(keyName) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
  } catch (_) { /* already loaded */ }

  chrome.tabs.sendMessage(tab.id, { type: 'PF9_SPECIAL_KEY', key: keyName }, () => {
    if (chrome.runtime.lastError) {
      setStatus('error', 'Could not reach page');
      setTimeout(() => setStatus('idle', 'Ready'), 2000);
    }
  });
}

document.querySelectorAll('.btn-key[data-key]').forEach((btn) => {
  btn.addEventListener('click', () => sendSpecialKey(btn.dataset.key));
});

// ── Boot: read instance name + pending/saved credentials on popup open ───────
chrome.storage.local.get('pf9_settings', (data) => {
  const s = data.pf9_settings || {};
  const opEnabled = s.opEnabled !== false; // default ON
  _vault  = s.vault  || '';
  _prefix = s.prefix || 'PF9 - ';

  const credsSection = document.getElementById('credsSection');
  if (!opEnabled) {
    // 1Password integration disabled — hide entire credentials section
    if (credsSection) credsSection.style.display = 'none';
    return;
  }

  initInstanceContext();
});